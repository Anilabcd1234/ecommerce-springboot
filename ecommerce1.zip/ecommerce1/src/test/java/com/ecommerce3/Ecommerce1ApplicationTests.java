package com.ecommerce3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ecommerce1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
